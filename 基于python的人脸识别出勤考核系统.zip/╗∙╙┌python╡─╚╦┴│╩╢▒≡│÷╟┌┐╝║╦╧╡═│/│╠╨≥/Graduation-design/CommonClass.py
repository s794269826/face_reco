#-*-coding:utf8-*-
import pymysql, traceback
from PyQt5 import QtWidgets
import urllib.request, urllib.parse
from aip import AipFace

class Common(object):
    def delete_data(self, sql):
        try:
            self.conn = pymysql.connect(
                host='localhost',
                user='root',
                passwd='',
                db='info',
                charset='utf8',
            )
            self.cur = self.conn.cursor()
            self.cur.execute(sql)
            result = self.conn.commit()
            return result
        except:
            traceback.print_exc()
            self.conn.rollback()
        finally:
            self.cur.close()
            self.conn.close()
        return None

    def get_data(self, sql):
        try:
            self.conn = pymysql.connect(
                host='localhost',
                user='root',
                passwd='',
                db='info',
                charset='utf8',
            )
            self.cur = self.conn.cursor()

            print ("sql:", sql)

            self.cur.execute(sql)
            self.conn.commit()
            self.rows = self.cur.fetchall()
            self.row = self.cur.rowcount  # 取得记录个数，用于设置表格的行数
            # self.vol = len(self.rows[0])  # 取得字段数，用于设置表格的列数


            return self.rows, self.row
        except:
            traceback.print_exc()
            self.conn.rollback()
        finally:
            self.cur.close()
            self.conn.close()

    def insert_data(self, sql, sql_2):
        try:
            self.conn = pymysql.connect(
                host='localhost',
                user='root',
                passwd='',
                db='info',
                charset='utf8',
            )
            self.cur = self.conn.cursor()

            print ("sql:", sql)
            print("sql_2:", sql_2)
            self.cur.execute(sql_2)
            rows = self.cur.rowcount
            print ("rows:", rows)
            if rows == 0:
                self.cur.execute(sql)
                self.conn.commit()

            else:
                return -1
        except:
            traceback.print_exc()
            self.conn.rollback()
        finally:
            self.cur.close()
            self.conn.close()
        return 0

    def insert_data_one(self, sql):
        try:
            self.conn = pymysql.connect(
                host='localhost',
                user='root',
                passwd='',
                db='info',
                charset='utf8',
            )
            self.cur = self.conn.cursor()

            print ("sql:", sql)

            self.cur.execute(sql)
            self.conn.commit()

        except:
            self.conn.rollback()
            traceback.print_exc()

        finally:
            self.cur.close()
            self.conn.close()
        return 0

    def getAccess_token(self):
        # client_id 为官网获取的AK， client_secret 为官网获取的SK
        host = 'https://aip.baidubce.com/oauth/2.0/token'
        data = {"grant_type": "client_credentials",
                "client_id": "8awG3LpDZzMQXvnCZHImf6T3",
                "client_secret": "Ynzyu5OzdG60sB5qiTFI6BQOqyHK9Ofh"}
        data_urlencode = urllib.parse.urlencode(data).encode(encoding='UTF8')
        req = urllib.request.Request(url=host, data=data_urlencode)
        req.add_header('Content-Type', 'application/json; charset=UTF-8')
        response = urllib.request.urlopen(req)
        content = response.read()
        if (content):
            content = content.decode()
            content = eval(content)
            print (type(content))
            return content['access_token']

    def new_AipFace(self):
        """ 你的 APPID AK SK """
        APP_ID = '10946552'
        API_KEY = '8awG3LpDZzMQXvnCZHImf6T3'
        SECRET_KEY = 'Ynzyu5OzdG60sB5qiTFI6BQOqyHK9Ofh'

        self.client = AipFace(APP_ID, API_KEY, SECRET_KEY)
        return self.client
