#-*-coding:utf8-*-
import cv2
import traceback, numpy

class getPhoto():
    # 人脸图像提取
    def getP(self, imgPath):
        try:
            cascade = cv2.CascadeClassifier("Source\haarcascade_frontalface_alt.xml")
            cascade.load("F:\Git\Graduation-design\Source\haarcascade_frontalface_alt.xml")

            self.img = cv2.imdecode(numpy.fromfile(imgPath, dtype=numpy.uint8), -1) # 读取图像
            gray = cv2.cvtColor(self.img, cv2.COLOR_BGR2GRAY)
            rect = cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5, minSize=(5, 5),
                                            flags=cv2.CASCADE_SCALE_IMAGE)
            if not rect is ():

                for x, y, z, w in rect:
                    cv2.rectangle(self.img, (x, y), (x + z, y + w), (0, 0, 255), 2)

            cv2.imshow('image', self.img)
            cv2.waitKey(0)
            cv2.destroyWindow("Camera")
        except:
            traceback.print_exc()

# if __name__ == '__main__':
#     photo = getPhoto()
#     photo.getP(r'C:\Users\ycy\Desktop\IMG_0016-1705(2).jpg')
