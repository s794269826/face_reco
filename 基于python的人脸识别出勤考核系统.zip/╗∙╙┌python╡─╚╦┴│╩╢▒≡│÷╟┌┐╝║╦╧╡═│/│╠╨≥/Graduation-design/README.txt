﻿1、入口为UI--》main_windows_main.py
2、venv1为虚拟环境
3、本系统用的大部分css在Qss--》slivery.css
4、Source文件夹为临时图片、css资源、分类器资源
