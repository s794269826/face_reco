#-*-coding:utf8-*-
import CommonClass
from PyQt5 import QtWidgets

class Face_SDK():
    A = CommonClass.Common()
    client = A.new_AipFace()

    """ 读取图片 """
    def get_file_content(self, filePath):
        with open(filePath, 'rb') as fp:
            return fp.read()

    def face_test(self, imgPath):
        """ 读取图片 """
        image = self.get_file_content(imgPath)

        """ 调用人脸检测 """
        # self.client.detect(image);

        """ 如果有可选参数 """
        options = {}
        # options["max_face_num"] = 2
        options["face_fields"] = "qualities"

        """ 带参数调用人脸检测 """
        content = self.client.detect(image, options)
        return content

    def face_compare(self, imgPath_1=None, imgPath_2=None):
        """ 读取图片 """
        images = [self.get_file_content(imgPath_1), self.get_file_content(imgPath_2)]

        """ 调用人脸比对 """
        # self.client.match(images);

        """ 如果有可选参数 """
        options = {}
        # options["ext_fields"] = "qualities"
        # options["image_liveness"] = ",faceliveness"
        # options["types"] = "7,13"

        """ 带参数调用人脸比对 """
        content = self.client.match(images, options)
        if content:
            print(content)
            return content
        else:
            QtWidgets.QMessageBox.information(self, "提示", "对比失败，无返回参数！", QtWidgets.QMessageBox.Ok)

    def face_recognition(self):
        groupId = "group1,group2"

        """ 读取图片 """
        image = self.get_file_content('example.jpg')

        """ 调用人脸识别 """
        self.client.identifyUser(groupId, image);

        """ 如果有可选参数 """
        options = {}
        options["ext_fields"] = "faceliveness"
        options["user_top_num"] = 3

        """ 带参数调用人脸识别 """
        self.client.identifyUser(groupId, image, options)

    def face_auth(self):
        uid = "user1"

        groupId = "group1,group2"

        """ 读取图片 """
        image = self.get_file_content('example.jpg')

        """ 调用人脸认证 """
        self.client.verifyUser(uid, groupId, image);

        """ 如果有可选参数 """
        options = {}
        options["top_num"] = 3
        options["ext_fields"] = "faceliveness"

        """ 带参数调用人脸认证 """
        self.client.verifyUser(uid, groupId, image, options)

    def face_register(self):
        uid = "user1"

        userInfo = "user's info"

        groupId = "group1,group2"

        """ 读取图片 """
        image = self.get_file_content('example.jpg')

        """ 调用人脸注册 """
        self.client.addUser(uid, userInfo, groupId, image);

        """ 如果有可选参数 """
        options = {}
        options["action_type"] = "replace"

        """ 带参数调用人脸注册 """
        self.client.addUser(uid, userInfo, groupId, image, options)

    def face_cover(self):
        uid = "user1"

        userInfo = "user's info"

        groupId = "group1"

        """ 读取图片 """
        image = self.get_file_content('example.jpg')

        """ 调用人脸更新 """
        self.client.updateUser(uid, userInfo, groupId, image);

        """ 如果有可选参数 """
        options = {}
        options["action_type"] = "replace"

        """ 带参数调用人脸更新 """
        self.client.updateUser(uid, userInfo, groupId, image, options)

    def face_dlete(self):
        uid = "user1"

        """ 调用人脸删除 """
        self.client.deleteUser(uid);

        """ 如果有可选参数 """
        options = {}
        options["group_id"] = "group1"

        """ 带参数调用人脸删除 """
        self.client.deleteUser(uid, options)

    def face_infoQuery(self):
        uid = "user1"

        """ 调用用户信息查询 """
        self.client.getUser(uid);

        """ 如果有可选参数 """
        options = {}
        options["group_id"] = "group1"

        """ 带参数调用用户信息查询 """
        self.client.getUser(uid, options)

