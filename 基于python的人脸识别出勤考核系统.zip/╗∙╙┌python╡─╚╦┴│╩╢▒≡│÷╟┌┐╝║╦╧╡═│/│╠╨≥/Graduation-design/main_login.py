#-*-coding:utf8-*-
import sys
from PyQt5.QtWidgets import QApplication, QFileDialog
import read_camera, open_camera, dataSet, train_model, open_image
from UI.main_windows_main import main_windows

from UI import loginGUI
import traceback, pymysql
from PyQt5 import QtWidgets, QtGui

class MyWindow(QtWidgets.QWidget, loginGUI.Ui_Form):
    def __init__(self):
        super(MyWindow, self).__init__()
        self.setupUi(self)
        self.pushButton.clicked.connect(self.msg)

    def msg(self):

        try:
            self.conn = pymysql.connect(
                host='localhost',
                user='root',
                passwd='',
                db='info',
                charset='utf8',
            )
            self.cur = self.conn.cursor()

            self.sqlstring = "select password from t_administrator where "
            temp_sqlstring = self.sqlstring
            print(temp_sqlstring)
            mystr = self.lineEdit.text()
            print(mystr)
            temp_sqlstring += "username = '" + mystr + "'"
            print(temp_sqlstring)
            self.cur.execute(temp_sqlstring)
            data = self.cur.fetchall()
            for row in data:
                username = row[0]
            print(self.lineEdit_2.text())
            if username == self.lineEdit_2.text():
                print('yes')
                self.close()
                self.w = main_windows()
                self.w.show()

            else:
                print('NO')
        except:
            # 输出异常信息
            traceback.print_exc()
            # 如果发生异常，则回滚
            self.conn.rollback()
        finally:
            self.conn.close()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    MainWindow = MyWindow()
    MainWindow.show()
    sys.exit(app.exec_())
