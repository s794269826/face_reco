#-*-coding:utf8-*-
import sys, traceback, os
import CommonClass
from PyQt5 import QtCore, QtGui
from PyQt5.QtWidgets import QMainWindow, QApplication, QTableWidgetItem, QFileDialog, QLabel, QInputDialog, QTextBrowser, QMessageBox
from UI.student_register_main import windows_register
from UI.main_windows import Ui_MainWindow
from open_camera import getPhoto
from dataSet import DataSet
from train_model import Model
from UI.image_recognition_main import image_recognition_window
from UI.image_compare_main import image_compare_class
from read_camera import Camera_reader
import face_image_get
import face_img_recogniton
import cv2, time
import traceback
from train_model import Model
from read_data import read_name_list
import pick_face

class main_windows(QMainWindow, Ui_MainWindow):
    p = getPhoto()

    def __init__(self):
        super(main_windows, self).__init__()
        self.setupUi(self)

        with open('..\\Qss\\silvery.css') as file:
            txt = file.readlines()
            txt = ''.join(txt).strip('\n')
        self.setStyleSheet(txt)

        self.btn_add_stu.clicked.connect(self.add_student)  # 添加学生信息
        self.btn_find.clicked.connect(self.find) # 查询学生信息
        self.btn_find_stu.clicked.connect(self.find_stu) # 获取学生信息
        self.btn_delete_stu.clicked.connect(self.delete) # 删除学生信息
        self.btn_edit_stu.clicked.connect(self.edit) # 修改学生信息
        self.btn_getface_stu.clicked.connect(self.get_face)  #录入学生人脸
        self.btn_stu_update.clicked.connect(self.stu_face_update) #学生人脸检测更新
        self.btn_face_compare.clicked.connect(self.face_compare) # 人脸比对
        self.btn_face_recogniton.clicked.connect(self.face_recognitnon) # 摄像人脸识别
        self.btn_imgFace_get.clicked.connect(self.face_get) # 人脸提取
        self.btn_imgFace_recognition.clicked.connect(self.face_img_rcognition) # 图像人脸识别
        self.btn_cameraFace_get.clicked.connect(self.face_get_camera) # 摄像人脸采集
        self.btn_new_course.clicked.connect(self.new_course) # 创建新的课程
        self.btn_add_course.clicked.connect(self.addCourse) # 添加课程
        self.addcommobox_dept_2()
        self.addcommobox_grade_2()
        self.addcommobox_class_2()
        self.addcommobox_course_2()
        self.pushButton.clicked.connect(self.Many_import) #导入点名名单
        self.btn_haveName.clicked.connect(self.haveName) # 点名
        self.btn_noget.clicked.connect(self.noget_name) # 生成未到名单
        self.btn_commit.clicked.connect(self.commitName) # 确认名单
        self.btn_faceExersise.clicked.connect(self.face_excersise) # 人脸训练

    '''学生信息管理'''

    def add_student(self):
        try:
            self.hide()
            register = windows_register()
            register.show()
            register.exec_()
            self.show()
            self.comboBox.clear()
            self.comboBox_2.clear()
            self.comboBox_3.clear()
            self.comboBox_4.clear()
            self.addcommobox_dept_2()
            self.addcommobox_grade_2()
            self.addcommobox_class_2()
            self.addcommobox_course_2()
            self.addcommobox_dept()
            self.addcommobox_grade()
            self.addcommobox_class()
            self.addcommobox_course()
        except:
            traceback.print_exc()

    rows = []
    def find(self):
        try:
            self.tableWidget.clearContents()  # 每一次查询时清除表格中信息
            global rows
            self.sqlstring = "select t_student.Sid, t_student.Sname, t_student.Sage, t_student.Ssex, " \
                             "t_grade.Sgrade, t_class.Sclass, t_dept.Sdept, t_student.Saddr " \
                             "from t_student LEFT OUTER JOIN t_grade on t_student.Sgrade=t_grade.id " \
                             "LEFT OUTER JOIN t_class on  t_student.Sclass=t_class.id LEFT OUTER JOIN" \
                             " t_dept on t_student.Sdept=t_dept.id where"
            temp_sqlstring = self.sqlstring
            temp_sqlstring += " Sname like '%" + self.lineEdit.text() + "%'"
            get_table = CommonClass.Common()
            rows,row = get_table.get_data(temp_sqlstring)
            if row == 0:
                vol = 0
                QMessageBox.information(self, "提示", "查无此人物记录！", QMessageBox.Ok)
            else:
                vol = len(rows[0])# 取得记录个数，用于设置表格的行数

            self.tableWidget.setRowCount(row)
            self.tableWidget.setColumnCount(vol)
            self.tableWidget.setHorizontalHeaderLabels(['学号', '姓名', '年龄', '性别', '年级', '班级', '院系', '存档'])

            for i in range(row):
                for j in range(vol):
                    temp_data = rows[i][j]  # 临时记录，不能直接插入表格
                    data = QTableWidgetItem(str(temp_data))  # 转换后可插入表格
                    self.tableWidget.setItem(i, j, data)
        except:
            traceback.print_exc()

    row = 0
    def find_stu(self):
        try:
            global row
            row = self.tableWidget.currentRow()
            if row < 0:
                QMessageBox.information(self, "提示", "查无此人物记录！", QMessageBox.Ok)
            else:
                self.cb_class.clear()
                self.cb_grade.clear()
                self.cb_dept.clear()
                self.cb_course.clear()
                self.addcommobox_grade()
                self.addcommobox_class()
                self.addcommobox_dept()
                self.addcommobox_course()

                data = rows[row]
                self.le_id.setText(data[0])
                self.le_name.setText(data[1])
                self.le_age.setText(str(data[2]))
                self.le_sex.setText(data[3])
                self.cb_grade.setCurrentText(data[4])
                self.cb_class.setCurrentText(data[5])
                self.cb_dept.setCurrentText(data[6])
        except:
            traceback.print_exc()

    def addcommobox_grade(self): # 下拉框获取
        sql = "select Sgrade from t_grade"
        s = CommonClass.Common()
        rows, row = s.get_data(sql)
        for i in rows:
            self.cb_grade.addItem(i[0])
    def addcommobox_class(self):
        sql = "select Sclass from t_class"
        s = CommonClass.Common()
        rows, row = s.get_data(sql)
        for i in rows:
            self.cb_class.addItem(i[0])
    def addcommobox_dept(self):
        sql = "select Sdept from t_dept"
        s = CommonClass.Common()
        rows, row = s.get_data(sql)
        for i in rows:
            self.cb_dept.addItem(i[0])
    def addcommobox_course(self):
        sql = "select Cname from t_course"
        s = CommonClass.Common()
        rows, row = s.get_data(sql)
        for i in rows:
            self.cb_course.addItem(i[0])

    def delete(self):
        try:
            self.sqlstring = "delete from t_student where Sid = '" + self.le_id.text() + "'"
            temp_sqlstring = self.sqlstring
            get_table = CommonClass.Common()
            result = get_table.delete_data(temp_sqlstring)
            print ("sdasd:",result)
            if result is not None:
                QMessageBox.information(self, "提示", "删除失败！", QMessageBox.Ok)
            else:
                path = rows[row][7]
                if os.path.exists(path):
                    os.remove(path)
                QMessageBox.information(self, "提示", "删除记录成功！", QMessageBox.Ok)
        except:
            traceback.print_exc()

    def edit(self): # 修改学生信息
        try:
            sql_grade = "select id from t_grade where Sgrade='" + self.cb_grade.currentText() + "'"
            sql_class = "select id from t_class where Sclass='" + self.cb_class.currentText() + "'"
            sql_dept = "select id from t_dept where Sdept='" + self.cb_dept.currentText() + "'"
            s = CommonClass.Common()
            Sgrade, g = s.get_data(sql_grade)
            Sclass, c = s.get_data(sql_class)
            Sdept, d = s.get_data(sql_dept)

            Sage = self.le_age.text()
            Ssex = self.le_sex.text()
            Sid = self.le_id.text()
            self.sqlstring = "update t_student set Sage='%s',SSex='%s',Sgrade='%s',Sclass='%s',Sdept='%s' where Sid = '%s'"%(Sage, Ssex, str(Sgrade[0][0]), str(Sclass[0][0]), str(Sdept[0][0]), Sid)
            temp_sqlstring = self.sqlstring
            get_table = CommonClass.Common()
            result = get_table.delete_data(temp_sqlstring)

            if result is not None:
                QMessageBox.information(self, "提示", "更新失败！", QMessageBox.Ok)
            else:
                QMessageBox.information(self, "提示", "更新记录成功！", QMessageBox.Ok)
        except:
            traceback.print_exc()


    def new_course(self):
        text, ok = QInputDialog.getText(self, '创建新课程', '请输入课程名：')
        if ok:
            print("text:", text)
            if text.strip() == '':
                QMessageBox.information(self, "提示", "课程名不能为空！", QMessageBox.Ok)
            else:
                sql = "Insert into t_course(Cname) VALUES ('" + text + "') "
                sql_2 = "select * from t_course where Cname = '" + text + "'"
                s = CommonClass.Common()
                flag = s.insert_data(sql, sql_2)
                if flag == 0:
                    QMessageBox.information(self, "提示", "创建课程成功！", QMessageBox.Ok)
                    self.cb_course.clear()
                    self.addcommobox_course()
                    self.addcommobox_course_2()

                else:
                    QMessageBox.information(self, "提示", "该课程已存在！", QMessageBox.Ok)

    def addCourse(self): # 添加学生课程信息
        try:
            sql_course = "select Cid from t_course where Cname='" + self.cb_course.currentText() + "'"

            s = CommonClass.Common()
            Cid, c = s.get_data(sql_course)
            Sid = self.le_id.text()
            temp_sqlstring = "Insert into t_sc(Sid, Cid) VALUES ('%s', '%s')"%(Sid ,Cid[0][0])
            temp_sqlstring_2 = "select * from t_sc where Sid='%s'and Cid='%s'"%(Sid ,Cid[0][0])
            get_table = CommonClass.Common()
            result = get_table.insert_data(temp_sqlstring, temp_sqlstring_2)

            if result == -1:
                QMessageBox.information(self, "提示", "学生添加课程失败！", QMessageBox.Ok)
            else:
                QMessageBox.information(self, "提示", "学生添加课程成功！", QMessageBox.Ok)
        except:
            traceback.print_exc()

    def get_face(self): #录入学生人脸
        try:
            path = "D:\\myProject\\pictures\\dataset\\"
            if self.le_name.text().strip() is not '':
                name = self.le_name.text().strip()
                self.groupBox_3.setEnabled(False)
                self.label_loadTip.setText("正在采集，请稍后。。。")
                path_name = self.p.CatchPICFromVideo("camera", 0, 50, name)
                if os.path.exists(path+name):
                    pass
                else:
                    os.makedirs(path+name)
                pick_face.readPicSaveFace(path_name, path+name, '.jpg','.JPG','png','PNG')
                self.groupBox_3.setEnabled(True)
                self.label_loadTip.setText("")
                QMessageBox.information(self, "提示", "采集成功！", QMessageBox.Ok)
                # dataset = DataSet('D:\myProject\pictures\dataset')
                # model = Model()
                # model.read_trainData(dataset)
                # model.build_model()
                # model.train_model()
                # model.evaluate_model()
                # model.save()
                # self.label_loadTip.clear()
                # self.groupBox_3.setEnabled(True)
                # QMessageBox.information(self, "提示", "录入成功！", QMessageBox.Ok)
            else:
                QMessageBox.information(self, "提示", "请选择人物在录入图像！", QMessageBox.Ok)
        except:
            traceback.print_exc()

    '''人脸操作'''

    def stu_face_update(self): # 更新人脸库
        self.hide()
        recog = image_recognition_window()
        recog.show()
        recog.exec_()
        self.show()

    def face_compare(self): # 人脸比对
        self.hide()
        comp = image_compare_class()
        comp.show()
        comp.exec_()
        self.show()

    def face_recognitnon(self):  # 摄像人脸识别
        camera = Camera_reader()
        camera.build_camera()

    def face_get(self): # 人脸提取
        try:
            imgName, imgType = QFileDialog.getOpenFileName(self, "打开图片", "",
                                                                     " *.jpg;;*.png;;*.jpeg;;*.bmp;;All Files (*)")
            if imgName is not '':
                get_f = face_image_get.getPhoto()
                get_f.getP(imgName)
        except:
            traceback.print_exc()

    def face_img_rcognition(self): # 图像人脸识别
        try:
            imgName, imgType = QFileDialog.getOpenFileName(self, "打开图片", "",
                                                           " *.jpg;;*.png;;*.jpeg;;*.bmp;;All Files (*)")
            if imgName is not '':
                camera = face_img_recogniton.Camera_reader()
                camera.build_camera(imgName)
        except:
            traceback.print_exc()

    '''录入suoyou人脸'''
    def face_get_camera(self):
        try:
            path = "D:\\myProject\\pictures\\dataset\\"
            if self.le_getface_name.text().strip() is not '':
                # self.groupBox_3.setEnabled(False)
                #self.label_loadTip.setText("正在采集，请稍后。。。")
                name = "Tourists_"+self.le_getface_name.text().strip()
                self.tab_name.setEnabled(False)
                path_name = self.p.CatchPICFromVideo("camera", 0, 50, name)
                if os.path.exists(path+name):
                    pass
                else:
                    os.makedirs(path+name)
                pick_face.readPicSaveFace(path_name, path+name, '.jpg','.JPG','png','PNG')
                QMessageBox.information(self, "提示", "采集成功！", QMessageBox.Ok)
                self.tab_name.setEnabled(True)
                # QMessageBox.information(self, "提示", "正在采集，请稍后！", QMessageBox.Ok)
                # dataset = DataSet('D:\myProject\pictures\dataset')
                # model = Model()
                # model.read_trainData(dataset)
                # model.build_model()
                # model.train_model()
                # model.evaluate_model()
                # model.save()
                # self.label_loadTip.clear()
                # self.label_loadTip.setEnabled(False)
                # QMessageBox.information(self, "提示", "采集成功！", QMessageBox.Ok)
                # self.tab_name.setEnabled(True)
            else:
                QMessageBox.information(self, "提示", "请选择人物再采集图像！", QMessageBox.Ok)
        except:
            traceback.print_exc()


    '''点名'''

    def addcommobox_grade_2(self): # 下拉框获取
        sql = "select Sgrade from t_grade"
        s = CommonClass.Common()
        rows, row = s.get_data(sql)
        for i in rows:
            self.comboBox_2.addItem(i[0])
    def addcommobox_class_2(self):
        sql = "select Sclass from t_class"
        s = CommonClass.Common()
        rows, row = s.get_data(sql)
        for i in rows:
            self.comboBox_3.addItem(i[0])
    def addcommobox_dept_2(self):
        sql = "select Sdept from t_dept"
        s = CommonClass.Common()
        rows, row = s.get_data(sql)
        for i in rows:
            self.comboBox.addItem(i[0])
    def addcommobox_course_2(self):
        sql = "select Cname from t_course"
        s = CommonClass.Common()
        rows, row = s.get_data(sql)
        for i in rows:
            self.comboBox_4.addItem(i[0])

    def Many_import(self):

        try:
            sql_grade = "select id from t_grade where Sgrade='" + self.comboBox_2.currentText() + "'"
            sql_class = "select id from t_class where Sclass='" + self.comboBox_3.currentText() + "'"
            sql_dept = "select id from t_dept where Sdept='" + self.comboBox.currentText() + "'"
            sql_course = "select Cid from t_course where Cname='" + self.comboBox_4.currentText() + "'"

            s = CommonClass.Common()
            Sgrade, g = s.get_data(sql_grade)
            Sclass, c = s.get_data(sql_class)
            Sdept, d = s.get_data(sql_dept)
            Cname, a = s.get_data(sql_course)

            sql_2 = "DELETE FROM t_flag"
            s.insert_data_one(sql_2)
            temp_sqlstring = "insert into t_flag (Sid, Sname, Course) select t_student.Sid, " \
                             "t_student.Sname, t_course.Cname from t_student LEFT OUTER JOIN t_grade on" \
                             " t_student.Sgrade=t_grade.id LEFT OUTER JOIN t_class on " \
                             " t_student.Sclass=t_class.id LEFT OUTER JOIN t_dept on" \
                             " t_student.Sdept=t_dept.id left outer join t_sc on " \
                             "t_sc.Sid=t_student.Sid left outer join t_course on " \
                             "t_course.Cid=t_sc.Cid where "
            is_first = False # 是否是第一个参数
            print (type(Cname[0][0]))
            print(Cname[0][0])
            temp_sqlstring += "t_sc.Cid = '" + str(Cname[0][0]) + "'"
            if self.checkBox.isChecked():
                if is_first:
                    is_first = False
                    temp_sqlstring += "t_student.Sdept = '" + str(Sdept[0][0]) + "'"
                else:
                    temp_sqlstring += " and t_student.Sdept = '" + str(Sdept[0][0]) + "'"

            if self.checkBox_2.isChecked():

                if is_first:
                    is_first = False
                    temp_sqlstring += "t_student.Sgrade = '" + str(Sgrade[0][0]) + "'"
                else:
                    temp_sqlstring += " and t_student.Sgrade = '" + str(Sgrade[0][0]) + "'"

            if self.checkBox_3.isChecked():

                if is_first:
                    is_first = False
                    temp_sqlstring += "t_student.Sclass = '" + str(Sclass[0][0]) + "'"
                else:
                    temp_sqlstring += " and t_student.Sclass = '" + str(Sclass[0][0]) + "'"

            if not (is_first):
                print (temp_sqlstring)
                s.insert_data_one(temp_sqlstring)
                sql = "select * from t_flag"
                rows, row = s.get_data(sql)
                print (rows, row)

                if row == 0:
                    vol = 0
                    QMessageBox.information(self, "提示", "查无记录！", QMessageBox.Ok)
                else:
                    vol = len(rows[0])# 取得记录个数，用于设置表格的行数
                    print ("vol:",vol)
                self.tb_name.setRowCount(row)
                self.tb_name.setColumnCount(vol)
                self.tb_name.setHorizontalHeaderLabels(['学号', '姓名', '课程'])
                for i in range(row):
                    for j in range(vol):
                        temp_data = rows[i][j]  # 临时记录，不能直接插入表格
                        data = QTableWidgetItem(temp_data)  # 转换后可插入表格
                        self.tb_name.setItem(i, j, data)
        except:
            traceback.print_exc()

    def find_nametab(self):
        try:
            self.tableWidget_5.clearContents()  # 每一次查询时清除表格中信息
            self.tableWidget_5.setHorizontalHeaderLabels(['学号', '姓名', '年龄', '性别', '年级', '班级', '院系', '存档'])
            global rows
            self.sqlstring = "select t_student.Sid, t_student.Sname, t_student.Sage, t_student.Ssex, " \
                             "t_grade.Sgrade, t_class.Sclass, t_dept.Sdept, t_student.Saddr, t_course.Cname " \
                             "from t_student LEFT OUTER JOIN t_grade on t_student.Sgrade=t_grade.id " \
                             "LEFT OUTER JOIN t_class on  t_student.Sclass=t_class.id LEFT OUTER JOIN" \
                             " t_dept on t_student.Sdept=t_dept.id LEFT outer join t_sc on " \
                             "t_student.Sid=t_sc.Sid left outer join t_course on t_sc.Cid=t_course.Cid where"
            temp_sqlstring = self.sqlstring
            temp_sqlstring += " Sname like '%" + self.lineEdit_2.text() + "%'"
            get_table = CommonClass.Common()
            rows,row = get_table.get_data(temp_sqlstring)
            if row == 0:
                vol = 0
                QMessageBox.information(self, "提示", "查无此人物记录！", QMessageBox.Ok)
            else:
                vol = len(rows[0])# 取得记录个数，用于设置表格的行数

            self.tableWidget_5.setRowCount(row)
            self.tableWidget_5.setColumnCount(vol)
            for i in range(row):
                for j in range(vol):
                    temp_data = rows[i][j]  # 临时记录，不能直接插入表格
                    data = QTableWidgetItem(str(temp_data))  # 转换后可插入表格
                    self.tableWidget_5.setItem(i, j, data)
        except:
            traceback.print_exc()


    def haveName(self):
        self.tb_name_2.clearContents()
        self.tb_name_3.clearContents()

        self.model = Model()
        self.model.load()
        self.img_size = 128

        self.tb_name_2.setRowCount(200)
        self.tb_name_2.setColumnCount(1)
        s = CommonClass.Common()
        cameraCapture = cv2.VideoCapture(0)  # 若打开视频则将 0 换成 ‘xxxx.avi’

        try:
            # opencv文件中人脸级联文件的位置，用于帮助识别图像或者视频流中的人脸
            face_cascade = cv2.CascadeClassifier('Source\haarcascade_frontalface_alt.xml')
            face_cascade.load("F:\Git\Graduation-design\Source\haarcascade_frontalface_alt.xml")

            # 读取dataset数据集下的子文件夹名称
            name_list = read_name_list('D:\myProject\pictures\dataset')

            # 打开摄像头并开始读取画面
            success, frame = cameraCapture.read()
            i = 0
            name = []
            while success and cv2.waitKey(1) == -1:
                success, frame = cameraCapture.read()
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)  # 图像灰化
                faces = face_cascade.detectMultiScale(gray, 1.3, 5)  # 识别人脸
                for (x, y, w, h) in faces:
                    ROI = gray[x:x + w, y:y + h]
                    ROI = cv2.resize(ROI, (self.img_size, self.img_size), interpolation=cv2.INTER_LINEAR)
                    label, prob = self.model.predict(ROI)  # 利用模型对cv2识别出的人脸进行比对
                    print("label:", label, "prob:", prob)
                    if prob > 0.8:  # 如果模型认为概率高于80%则显示为模型中已有的label
                        show_name = name_list[label]
                        print("name:", show_name)
                        if show_name in name:
                            pass
                        else:
                            name.append(show_name)
                            data = QTableWidgetItem(show_name)  # 转换后可插入表格
                            self.tb_name_2.setItem(i, 0, data)
                            sql_2 = "delete from t_flag where Sname = '" + show_name + "'"
                            s.insert_data_one(sql_2)

                            i += 1
                    else:
                        show_name = ''
                    cv2.putText(frame, show_name, (x, y - 20), cv2.FONT_HERSHEY_SIMPLEX, 1, 255, 2)  # 显示名字
                    frame = cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)  # 在人脸区域画一个正方形出来
                cv2.imshow("Camera", frame)

        except:
            traceback.print_exc()
        finally:
            cameraCapture.release()
            cv2.destroyAllWindows()  # 释放并销毁窗口

    def noget_name(self):
        try:
            s = CommonClass.Common()
            sql = "select * from t_flag"
            rows, row = s.get_data(sql)
            print(rows, row)
            self.tb_name.setHorizontalHeaderLabels(['学号', '姓名', '课程'])

            if row == 0:
                vol = 0
                QMessageBox.information(self, "提示", "无迟到学生！", QMessageBox.Ok)
            else:
                vol = len(rows[0])  # 取得记录个数，用于设置表格的行数
                print("vol:", vol)
            self.tb_name_3.setRowCount(row)
            self.tb_name_3.setColumnCount(vol)
            for i in range(row):
                for j in range(vol):
                    temp_data = rows[i][j]  # 临时记录，不能直接插入表格
                    data = QTableWidgetItem(str(temp_data))  # 转换后可插入表格
                    self.tb_name_3.setItem(i, j, data)
        except:
            traceback.print_exc()

    def commitName(self):
        try:

            name = str(int(time.time()))
            sql = "CREATE TABLE t_%s SELECT * FROM t_flag"%name
            s = CommonClass.Common()
            result = s.insert_data_one(sql)
            if result == 0:
                QMessageBox.information(self, "提示", "缺勤名单保存成功！", QMessageBox.Ok)
            else:
                QMessageBox.information(self, "提示", "缺勤名单保存失败！", QMessageBox.Ok)
        except:
            traceback.print_exc()

    def face_excersise(self):
        self.tab_name.setEnabled(False)
        QMessageBox.information(self, "提示", "正在录入，请稍后！", QMessageBox.Ok)
        dataset = DataSet('D:\myProject\pictures\dataset')
        model = Model()
        model.read_trainData(dataset)
        model.build_model()
        model.train_model()
        model.evaluate_model()
        model.save()
        self.label_loadTip.clear()
        self.label_loadTip.setEnabled(False)
        QMessageBox.information(self, "提示", "录入成功！", QMessageBox.Ok)
        self.tab_name.setEnabled(True)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    MainWindow = main_windows()
    MainWindow.show()
    sys.exit(app.exec_())
