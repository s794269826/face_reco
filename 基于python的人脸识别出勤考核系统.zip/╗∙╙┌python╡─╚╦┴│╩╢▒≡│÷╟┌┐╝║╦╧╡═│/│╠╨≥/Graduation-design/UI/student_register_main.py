#-*-coding:utf8-*-
import sys, traceback
from UI import student_register
import CommonClass
from PyQt5.QtWidgets import QDialog, QApplication, QLineEdit, QPushButton, QLabel, QInputDialog, QTextBrowser, QMessageBox

class windows_register(QDialog, student_register.Ui_student_register):
    def __init__(self):
        super(windows_register, self).__init__()
        self.setupUi(self)

        with open('..\\Qss\\silvery.css') as file:
            txt = file.readlines()
            txt = ''.join(txt).strip('\n')
        self.setStyleSheet(txt)

        self.addcommobox_sex()
        self.addcommobox_grade()
        self.addcommobox_class()
        self.addcommobox_dept()
        self.pushButton.clicked.connect(self.showDialog)
        self.pushButton_2.clicked.connect(self.showDialog)
        self.pushButton_3.clicked.connect(self.showDialog)
        self.pushButton_4.clicked.connect(self.showDialog)
        self.pushButton_6.clicked.connect(self.showDialog)
        self.pushButton_7.clicked.connect(self.showDialog)
        self.pushButton_5.clicked.connect(self.registerQuery)

    def addcommobox_sex(self):
        typelist = ['男', '女']
        for i in typelist:
            self.comboBox_4.addItem(i)

    def addcommobox_grade(self):
        sql = "select Sgrade from t_grade"
        s = CommonClass.Common()
        rows, row = s.get_data(sql)
        for i in rows:
            self.comboBox.addItem(i[0])
            self.comboBox.setCurrentText(" ")
    def addcommobox_class(self):
        sql = "select Sclass from t_class"
        s = CommonClass.Common()
        rows, row = s.get_data(sql)
        for i in rows:
            self.comboBox_2.addItem(i[0])
            self.comboBox.setCurrentText(" ")
    def addcommobox_dept(self):
        sql = "select Sdept from t_dept"
        s = CommonClass.Common()
        rows, row = s.get_data(sql)
        for i in rows:
            self.comboBox_3.addItem(i[0])
            self.comboBox.setCurrentText(" ")

    def showDialog(self):
        try:
            sender = self.sender()
            if sender == self.pushButton_7:
                text, ok = QInputDialog.getInt(self, '修改学号', '请输入学号：',min=1)
                if ok:
                        self.lineEdit_3.setText(str(text))
            elif sender == self.pushButton_2:
                text, ok = QInputDialog.getText(self, '修改姓名', '请输入姓名：')
                if ok:
                    if text.strip() == '':
                        QMessageBox.information(self, "提示", "不能为空！", QMessageBox.Ok)
                    else:
                        self.lineEdit.setText(text)
            elif sender == self.pushButton_6:
                text, ok = QInputDialog.getInt(self, '修改年龄', '请输入年龄：', min=1, max=99)
                if ok:
                        self.lineEdit_2.setText(str(text))
            elif sender == self.pushButton:
                text, ok = QInputDialog.getText(self, '添加年级', '请输入年级：')
                if ok:
                    print ("text:",text)
                    if text.strip() == '':
                        QMessageBox.information(self, "提示", "不能为空！", QMessageBox.Ok)
                    else:
                        sql = "Insert into t_grade(Sgrade) VALUES ('" + text + "') "
                        sql_2 = "select * from t_grade where Sgrade = '" + text + "'"
                        s = CommonClass.Common()
                        flag = s.insert_data(sql, sql_2)
                        if flag == 0:
                            QMessageBox.information(self, "提示", "添加年级成功！", QMessageBox.Ok)
                            self.comboBox.clear()
                            self.addcommobox_grade()
                            # self.Sgrade, row = s.get_data("SELECT LAST_INSERT_ID()")
                        else:
                            QMessageBox.information(self, "提示", "该年级已存在！", QMessageBox.Ok)

            elif sender == self.pushButton_3:
                text, ok = QInputDialog.getText(self, '添加班级', '请输入班级：', QLineEdit.Normal)
                if ok:
                    if text.strip() == '':
                        QMessageBox.information(self, "提示", "不能为空！", QMessageBox.Ok)
                    else:
                        sql = "Insert into t_class(Sclass) VALUES ('" + text + "') "
                        sql_2 = "select * from t_class where Sclass = '" + text + "'"

                        s = CommonClass.Common()
                        flag = s.insert_data(sql, sql_2)
                        if flag == 0:
                            QMessageBox.information(self, "提示", "添加班级成功！", QMessageBox.Ok)
                            self.comboBox_2.clear()
                            self.addcommobox_class()
                            # self.Sclass, row = s.get_data("SELECT LAST_INSERT_ID()")
                        else:
                            QMessageBox.information(self, "提示", "该班级已存在！", QMessageBox.Ok)
            elif sender == self.pushButton_4:
                text, ok = QInputDialog.getText(self, '添加院系', '请输入院系：')
                if ok:
                    if text.strip() == '':
                        QMessageBox.information(self, "提示", "不能为空！", QMessageBox.Ok)
                    else:
                        sql = "Insert into t_dept(Sdept) VALUES ('" + text +"') "
                        sql_2 = "select * from t_dept where Sdept = '" + text +"'"
                        s = CommonClass.Common()
                        flag = s.insert_data(sql, sql_2)
                        if flag == 0:
                            QMessageBox.information(self, "提示", "添加院系成功！", QMessageBox.Ok)
                            self.comboBox_3.clear()
                            self.addcommobox_dept()
                        else:
                            QMessageBox.information(self, "提示", "该院系已存在！", QMessageBox.Ok)
        except:
            traceback.print_exc()

    def registerQuery(self):
        try:

            self.textBrowser.setText("学号：" + self.lineEdit_3.text() + '\n' +
                                     "姓名：" + self.lineEdit.text() + '\n' +
                                     "年龄:" + self.lineEdit_2.text() + '\n' +
                                     "性别：" + self.comboBox_4.currentText() + '\n' +
                                     "年级:" + self.comboBox.currentText() + '\n' +
                                     "班级:" + self.comboBox_2.currentText() +'\n' +
                                     "院系:" + self.comboBox_3.currentText() +'\n'
                                     )
            if self.lineEdit.text().strip() == '' or self.lineEdit_2.text().strip() == '' or self.lineEdit_3.text().strip() == ''\
                    or self.comboBox.currentText().strip() == '' or self.comboBox_2.currentText().strip() == ''\
                    or self.comboBox_3.currentText().strip() == '' or self.comboBox_4.currentText().strip() == '':
                QMessageBox.information(self, "提示", "个人信息都是必填项，不能为空！", QMessageBox.Ok)
                return
            else:
                self.addr = "D:\\myProject\\pictures\\dataset\\%s\\" %(self.lineEdit.text())
                sql_grade = "select id from t_grade where Sgrade='" +self.comboBox.currentText() + "'"
                sql_class = "select id from t_class where Sclass='" + self.comboBox_2.currentText() + "'"
                sql_dept = "select id from t_dept where Sdept='" + self.comboBox_3.currentText() + "'"
                s = CommonClass.Common()
                Sgrade,g = s.get_data(sql_grade)
                Sclass, c = s.get_data(sql_class)
                Sdept, d = s.get_data(sql_dept)
                print (type(int(self.lineEdit_2.text())))
                sql = "Insert into t_student(Sid, Sname, Sage, Ssex, Sgrade, Sclass, Sdept, Saddr) VALUES ('" \
                      + self.lineEdit_3.text() + "','" \
                      + self.lineEdit.text() + "','" \
                      + self.lineEdit_2.text() + "','" \
                      + self.comboBox_4.currentText() + "','" \
                      + str(Sgrade[0][0]) + "','" \
                      + str(Sclass[0][0]) + "','" \
                      + str(Sdept[0][0]) + "','" \
                      + self.addr.replace('\\','\\\\') + "')"
                sql_2 = "select Sid from t_student where Sid = '" +self.lineEdit_3.text() +\
                        "' union " \
                        "select Sid from t_student where Sname = '" + self.lineEdit.text() + "'"
                s = CommonClass.Common()
                flag = s.insert_data(sql, sql_2)
                if flag == 0:
                    QMessageBox.information(self, "提示", "添加学生信息成功！", QMessageBox.Ok)
                    self.lineEdit.clear()
                    self.lineEdit_2.clear()
                    self.lineEdit_3.clear()
                    # self.textBrowser.clear()

                else:
                    QMessageBox.information(self, "提示", "添加学生信息失败！该生或许已存在", QMessageBox.Ok)
        except:
            traceback.print_exc()

# if __name__ == '__main__':
#     app = QApplication(sys.argv)
#     MainWindow = windows_register()
#     MainWindow.show()
#     sys.exit(app.exec_())