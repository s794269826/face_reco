# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'image_compare.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Image_Compare(object):
    def setupUi(self, Image_Compare):
        Image_Compare.setObjectName("Image_Compare")
        Image_Compare.resize(768, 630)
        self.groupBox = QtWidgets.QGroupBox(Image_Compare)
        self.groupBox.setGeometry(QtCore.QRect(30, 30, 351, 481))
        self.groupBox.setObjectName("groupBox")
        self.textBrowser = QtWidgets.QTextBrowser(self.groupBox)
        self.textBrowser.setGeometry(QtCore.QRect(10, 20, 321, 401))
        self.textBrowser.setObjectName("textBrowser")
        self.label_img_1 = QtWidgets.QLabel(self.groupBox)
        self.label_img_1.setGeometry(QtCore.QRect(50, 60, 241, 321))
        self.label_img_1.setText("")
        self.label_img_1.setObjectName("label_img_1")
        self.btn_img_1 = QtWidgets.QPushButton(self.groupBox)
        self.btn_img_1.setGeometry(QtCore.QRect(120, 440, 93, 28))
        self.btn_img_1.setObjectName("btn_img_1")
        self.groupBox_2 = QtWidgets.QGroupBox(Image_Compare)
        self.groupBox_2.setGeometry(QtCore.QRect(400, 30, 351, 481))
        self.groupBox_2.setObjectName("groupBox_2")
        self.textBrowser_2 = QtWidgets.QTextBrowser(self.groupBox_2)
        self.textBrowser_2.setGeometry(QtCore.QRect(10, 20, 321, 401))
        self.textBrowser_2.setObjectName("textBrowser_2")
        self.label_img_2 = QtWidgets.QLabel(self.groupBox_2)
        self.label_img_2.setGeometry(QtCore.QRect(50, 60, 241, 321))
        self.label_img_2.setText("")
        self.label_img_2.setObjectName("label_img_2")
        self.btn_img_2 = QtWidgets.QPushButton(self.groupBox_2)
        self.btn_img_2.setGeometry(QtCore.QRect(120, 440, 93, 28))
        self.btn_img_2.setObjectName("btn_img_2")
        self.groupBox_3 = QtWidgets.QGroupBox(Image_Compare)
        self.groupBox_3.setGeometry(QtCore.QRect(30, 530, 721, 81))
        self.groupBox_3.setObjectName("groupBox_3")
        self.btn_compare = QtWidgets.QPushButton(self.groupBox_3)
        self.btn_compare.setGeometry(QtCore.QRect(30, 30, 93, 28))
        self.btn_compare.setObjectName("btn_compare")
        self.label = QtWidgets.QLabel(self.groupBox_3)
        self.label.setGeometry(QtCore.QRect(150, 40, 141, 16))
        self.label.setObjectName("label")
        self.label_score = QtWidgets.QLabel(self.groupBox_3)
        self.label_score.setGeometry(QtCore.QRect(300, 40, 121, 16))
        self.label_score.setObjectName("label_score")
        self.label_tip = QtWidgets.QLabel(self.groupBox_3)
        self.label_tip.setGeometry(QtCore.QRect(450, 40, 181, 16))
        self.label_tip.setText("")
        self.label_tip.setObjectName("label_tip")

        self.retranslateUi(Image_Compare)
        QtCore.QMetaObject.connectSlotsByName(Image_Compare)

    def retranslateUi(self, Image_Compare):
        _translate = QtCore.QCoreApplication.translate
        Image_Compare.setWindowTitle(_translate("Image_Compare", "Compare"))
        self.groupBox.setTitle(_translate("Image_Compare", "图片"))
        self.btn_img_1.setText(_translate("Image_Compare", "选择图片"))
        self.groupBox_2.setTitle(_translate("Image_Compare", "图片"))
        self.btn_img_2.setText(_translate("Image_Compare", "选择图片"))
        self.groupBox_3.setTitle(_translate("Image_Compare", "对比"))
        self.btn_compare.setText(_translate("Image_Compare", "对比"))
        self.label.setText(_translate("Image_Compare", "得分（满分100.0）："))
        self.label_score.setText(_translate("Image_Compare", "0.0"))

