#-*-coding:utf8-*-
from PyQt5 import QtCore, QtGui, QtWidgets
import sys
import traceback
from UI import image_compare
import face_SDK

imgName_1 = ''
imgName_2 = ''
class image_compare_class(QtWidgets.QDialog, image_compare.Ui_Image_Compare):
    sdk = face_SDK.Face_SDK()

    def __init__(self):
        super(image_compare_class, self).__init__()
        self.setupUi(self)

        with open('..\\Qss\\silvery.css') as file:
            txt = file.readlines()
            txt = ''.join(txt).strip('\n')
        self.setStyleSheet(txt)

        self.btn_img_1.clicked.connect(self.open_image_1)
        self.btn_img_2.clicked.connect(self.open_image_2)
        self.btn_compare.clicked.connect(self.compare)

    def open_image_1(self):
        global imgName_1
        imgName_1, imgType = QtWidgets.QFileDialog.getOpenFileName(self, "打开图片", "",
                                                                 " *.jpg;;*.png;;*.jpeg;;*.bmp;;All Files (*)")
        print("imgName:", imgName_1)
        png = QtGui.QPixmap(imgName_1).scaled(self.label_img_1.width(), self.label_img_1.height(), QtCore.Qt.KeepAspectRatio)
        self.label_img_1.setPixmap(png)

    def open_image_2(self):
        global imgName_2
        imgName_2, imgType = QtWidgets.QFileDialog.getOpenFileName(self, "打开图片", "",
                                                                 " *.jpg;;*.png;;*.jpeg;;*.bmp;;All Files (*)")
        print("imgName:", imgName_2)
        png = QtGui.QPixmap(imgName_2).scaled(self.label_img_2.width(), self.label_img_2.height(), QtCore.Qt.KeepAspectRatio)
        self.label_img_2.setPixmap(png)


    def compare(self):
        try:
            self.btn_compare.setEnabled(False)
            self.label_tip.setText(' ')
            self.label_score.setText('0.0')
            if imgName_1 is not '' or imgName_2 is not '':
                content = self.sdk.face_compare(imgPath_1=imgName_1, imgPath_2=imgName_2)
                # content = content.decode() # 字节码转成dict
                # content = eval(content)
                score = content['result'][0]['score']
                self.label_score.setText(str(score))
                if score > 80.0:
                    self.label_tip.setText("很大可能是同一个人！")
                elif score < 20.0:
                    self.label_tip.setText("很大可能不是同一个人！")
                else:
                    self.label_tip.setText("不好判断！")
            else:
                QtWidgets.QMessageBox.information(self, "提示", "请选择两张图片！", QtWidgets.QMessageBox.Ok)

        except:
            traceback.print_exc()
        finally:
            self.btn_compare.setEnabled(True)

if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = image_compare_class()
    MainWindow.show()
    sys.exit(app.exec_())