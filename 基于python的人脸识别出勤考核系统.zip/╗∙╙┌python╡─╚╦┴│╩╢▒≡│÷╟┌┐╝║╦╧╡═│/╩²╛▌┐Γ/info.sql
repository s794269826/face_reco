/*
Navicat MySQL Data Transfer

Source Server         : server1
Source Server Version : 50639
Source Host           : localhost:3306
Source Database       : info

Target Server Type    : MYSQL
Target Server Version : 50639
File Encoding         : 65001

Date: 2018-04-25 20:56:29
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `t_1521933046`
-- ----------------------------
DROP TABLE IF EXISTS `t_1521933046`;
CREATE TABLE `t_1521933046` (
  `Sid` varchar(10) DEFAULT NULL,
  `Sname` varchar(100) DEFAULT NULL,
  `Course` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_1521933046
-- ----------------------------
INSERT INTO `t_1521933046` VALUES ('123', '小王', '数学', '40');
INSERT INTO `t_1521933046` VALUES ('124', '小明', '数学', '41');

-- ----------------------------
-- Table structure for `t_1522001548`
-- ----------------------------
DROP TABLE IF EXISTS `t_1522001548`;
CREATE TABLE `t_1522001548` (
  `Sid` varchar(10) DEFAULT NULL,
  `Sname` varchar(100) DEFAULT NULL,
  `Course` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_1522001548
-- ----------------------------

-- ----------------------------
-- Table structure for `t_administrator`
-- ----------------------------
DROP TABLE IF EXISTS `t_administrator`;
CREATE TABLE `t_administrator` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of t_administrator
-- ----------------------------
INSERT INTO `t_administrator` VALUES ('123', '456', '1');

-- ----------------------------
-- Table structure for `t_class`
-- ----------------------------
DROP TABLE IF EXISTS `t_class`;
CREATE TABLE `t_class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Sclass` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_class
-- ----------------------------
INSERT INTO `t_class` VALUES ('11', '二班 ');
INSERT INTO `t_class` VALUES ('13', '三班');
INSERT INTO `t_class` VALUES ('14', '五班');
INSERT INTO `t_class` VALUES ('15', '六班');
INSERT INTO `t_class` VALUES ('16', '十班');

-- ----------------------------
-- Table structure for `t_course`
-- ----------------------------
DROP TABLE IF EXISTS `t_course`;
CREATE TABLE `t_course` (
  `Cid` int(10) NOT NULL,
  `Cname` varchar(20) NOT NULL,
  `Tname` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_course
-- ----------------------------
INSERT INTO `t_course` VALUES ('101', '数学', '于老师');
INSERT INTO `t_course` VALUES ('102', '英语', '黄老师');
INSERT INTO `t_course` VALUES ('103', '语文', null);
INSERT INTO `t_course` VALUES ('104', '物理', null);

-- ----------------------------
-- Table structure for `t_dept`
-- ----------------------------
DROP TABLE IF EXISTS `t_dept`;
CREATE TABLE `t_dept` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Sdept` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_dept
-- ----------------------------
INSERT INTO `t_dept` VALUES ('3', 'wq ');
INSERT INTO `t_dept` VALUES ('4', '计算机');

-- ----------------------------
-- Table structure for `t_flag`
-- ----------------------------
DROP TABLE IF EXISTS `t_flag`;
CREATE TABLE `t_flag` (
  `Sid` varchar(10) DEFAULT NULL,
  `Sname` varchar(20) DEFAULT NULL,
  `Course` varchar(20) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_flag
-- ----------------------------
INSERT INTO `t_flag` VALUES ('125', 'aaa', '数学', '87');
INSERT INTO `t_flag` VALUES ('130', 'william', '数学', '88');

-- ----------------------------
-- Table structure for `t_grade`
-- ----------------------------
DROP TABLE IF EXISTS `t_grade`;
CREATE TABLE `t_grade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Sgrade` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_grade
-- ----------------------------
INSERT INTO `t_grade` VALUES ('22', '2015');
INSERT INTO `t_grade` VALUES ('23', '2031');
INSERT INTO `t_grade` VALUES ('24', '2014');
INSERT INTO `t_grade` VALUES ('25', '1111');
INSERT INTO `t_grade` VALUES ('27', '2018');
INSERT INTO `t_grade` VALUES ('28', '1');

-- ----------------------------
-- Table structure for `t_sc`
-- ----------------------------
DROP TABLE IF EXISTS `t_sc`;
CREATE TABLE `t_sc` (
  `Sid` varchar(10) NOT NULL DEFAULT '',
  `Cid` int(10) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_sc
-- ----------------------------
INSERT INTO `t_sc` VALUES ('123', '101', '1');
INSERT INTO `t_sc` VALUES ('123', '102', '2');
INSERT INTO `t_sc` VALUES ('124', '101', '3');
INSERT INTO `t_sc` VALUES ('125', '102', '4');
INSERT INTO `t_sc` VALUES ('125', '101', '5');
INSERT INTO `t_sc` VALUES ('125', '103', '6');
INSERT INTO `t_sc` VALUES ('125', '104', '7');
INSERT INTO `t_sc` VALUES ('130', '101', '8');

-- ----------------------------
-- Table structure for `t_student`
-- ----------------------------
DROP TABLE IF EXISTS `t_student`;
CREATE TABLE `t_student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Sid` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Sname` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `Sage` int(2) DEFAULT NULL,
  `Ssex` varchar(2) CHARACTER SET utf8 DEFAULT NULL,
  `Sgrade` int(11) DEFAULT NULL,
  `Sclass` int(11) DEFAULT NULL,
  `Sdept` int(11) DEFAULT NULL,
  `Saddr` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `Sid` (`Sid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of t_student
-- ----------------------------
INSERT INTO `t_student` VALUES ('3', '125', 'aaa', '12', '女', '22', '14', '3', 'D:\\myProject\\pictures\\dataset\\aaa\\');
INSERT INTO `t_student` VALUES ('4', '130', 'william', '21', '男', '24', '14', '4', 'D:\\myProject\\pictures\\dataset\\william\\');
